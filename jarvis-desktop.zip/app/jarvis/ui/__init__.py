"""Jarvis Desktop UI package."""
